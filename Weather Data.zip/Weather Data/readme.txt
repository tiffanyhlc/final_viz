README 

City Names:
CLT -> Charlotte, North Carolina
CQT -> Los Angeles, California
IND -> Indianapolis, Indiana
JAX -> Jacksonville, Florida
MDW -> Chicago, Illinois
PHL -> Philadelphia, Pennsylvania
PHX -> Pheonix, Arizona
